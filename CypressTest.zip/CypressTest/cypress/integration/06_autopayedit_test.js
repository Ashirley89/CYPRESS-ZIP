/// <reference types="cypress" />

// Navigate to Autopay - Verify page loads and displays successfully
describe('A registered user should be able to enable & disable autopay', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.login('auto.user+bo-pboq-2qlj@peachfinance.com', 'hello12345')
        cy.wait(5000)
        cy.url().should('include', '/loans')

// Adding Payment Method to Enable Autopay Before    
        cy.log('Adding Payment Method & Enabling Autopay')
        cy.wait(5000)
        cy.addpaymentMethod()
        cy.manageautoPay()  
        

        
    })

    it('user should be able to disable autopay', () => {
        cy.log('Removing Payment Method & Disabling Autopay')
        cy.wait(5000)
        cy.removepaymentMethod()
        //cy.autopayEnable()
        //cy.logout()
        
        
        
        
    })

})