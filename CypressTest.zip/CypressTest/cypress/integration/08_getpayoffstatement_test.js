/// <reference types="cypress" />


// Navigate to Get Payoff Statements tab
describe('A registered user should be able to login and access Get Pay Off Statements', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.login('auto.user+bo-pboq-2qlj@peachfinance.com', 'hello12345')
        cy.wait(5000)
        cy.url().should('include', '/loans')
        
    })



// Click and send payoff statement
    it('User should be able to get payoff statement', () => {
        cy.wait(5000)
        cy.get('button[label="Loan"]').click()
        cy.contains('Get payoff statement').click()
        cy.url().should('include','/get-payoff-statement')
        cy.get('[data-cy="radio-Email"] > [data-testid="label-no-custom-field"]').click()
        cy.get('.select__value-container').click()
        cy.get('#react-select-2-option-1').click()
        cy.get('button[class="Button__StyledButton-sc-1irh7c3-0 cJMvVs button border-none secondary"]').click()

// Verify Statement sends as expected
        cy.waitFor('Payoff statement successfully sent.')
        cy.contains('Payoff statement successfully sent.').should('exist')
        cy.logout()
    })
})   